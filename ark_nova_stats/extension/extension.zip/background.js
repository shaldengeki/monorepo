const apiEndpoint = "https://api.arknova.ouguo.us/graphql";
const apiDomain = "api.arknova.ouguo.us"

function makeAPIRequest(body) {
    let apiHeaders = new Headers();
    apiHeaders.append("Content-Type", "application/json");
  
    let apiRequest = new Request(apiEndpoint, {
      method: "POST",
      headers: apiHeaders,
      body: body,
    });
  
    return fetch(apiRequest);
}

var browser = (browser) ? browser : chrome;
let pattern = "https://*.boardgamearena.com/*";

function readEntireResponse(data) {
  let str = "";
  let decoder = new TextDecoder("utf-8");

  // Decode all the pushed data and assemble a string representing the entire response.
  if (data.length === 1) {
    str = decoder.decode(data[0]);
  } else {
    for (let i = 0; i < data.length; i++) {
      const stream = i !== data.length - 1;
      const decodedChunk = decoder.decode(data[i], { stream });
      str += decodedChunk;
    }
  }

  return str;
}

function handleLogsRequest(requestDetails) {
  let filter = browser.webRequest.filterResponseData(requestDetails.requestId);
  let encoder = new TextEncoder();

  const data = [];

  filter.ondata = (event) => {
    data.push(event.data);
  }

  filter.onstop = (event) => {
    const response = readEntireResponse(data);

    if (!response.includes("from the deck (scoring cards)")) {
      console.log("No scoring event seen, assuming this isn't an Ark Nova replay and skipping.");
      filter.write(encoder.encode(response));
      filter.disconnect();
      return {};
    }

    const apiPromise = makeAPIRequest(
      JSON.stringify({
        query: "mutation SubmitGameLog($logs: String!) {\n  submitGameLogs(logs: $logs) {\n    id\n  }\n}",
        variables: {
          logs: response,
        },
        operationName: "SubmitGameLog",
      })
    ).then(
      data => {
        console.log(`Made game logs API request: ${data.json()}`)
      }
    );

    filter.write(encoder.encode(response));
    filter.disconnect();

    return apiPromise;
  }

  return {};
}

function handleRatingsRequest(requestDetails) {
  const url = new URL(requestDetails.url);
  const tableId = parseInt(url.searchParams.get("id"), 10);

  if (tableId === null) {
    console.log("No table ID found in URL, bailing.");
    return {}
  }

  let filter = browser.webRequest.filterResponseData(requestDetails.requestId);
  let encoder = new TextEncoder();

  const data = [];

  filter.ondata = (event) => {
    data.push(event.data);
  }

  filter.onstop = (event) => {
    const response = readEntireResponse(data);

    const apiPromise = makeAPIRequest(
      JSON.stringify({
        query: "mutation SubmitGameRatings($ratings:String!,$tableId:Int!) {\n  submitGameRatings(ratings:$ratings,tableId:$tableId) {\n    id\n  }\n}",
        variables: {
          ratings: response,
          tableId: tableId,
        },
        operationName: "SubmitGameRatings",
      })
    ).then(
      data => {
        console.log(`Made game ratings API request: ${data.json()}`)
      }
    );

    filter.write(encoder.encode(response));
    filter.disconnect();

    return apiPromise;
  }

  return {};
}

function handleRequest(requestDetails) {
  // Only do more work if the user has enabled this feature.
  browser.storage.sync.get("recordGameLog").then((result) => {
    if (result !== undefined && result.recordGameLog) {
      if (requestDetails.url.includes("logs.html")) {
        return handleLogsRequest(requestDetails);
      } else if (requestDetails.url.includes("tableratingsupdate.html")) {
        return handleRatingsRequest(requestDetails);
      }
    }
  });

  return {};
}

browser.webRequest.onBeforeRequest.addListener(
  handleRequest,
  { urls: [pattern] },
  ["blocking"],
);

function modifyHeaders(requestDetails) {
  // BGA, for security reasons, prevents scripts on BGA from making requests to other domains via a CSP policy.
  // We intercept the CSP policy header and allowlist our domain in.
  let cspHeader = null;
  let cspHeaderIdx = null;
  for (var idx = 0; idx < requestDetails.responseHeaders.length; idx++) {
    let header = requestDetails.responseHeaders[idx];
    if (header.name.toLowerCase() === "content-security-policy") {
      cspHeader = header;
      cspHeaderIdx = idx;
    }
  }
  console.log("cspHeader", cspHeader);
  console.log("cspHeaderIdx", cspHeaderIdx);

  if (cspHeader === null) {
    // no CSP header; this is unexpected, but OK.
    // leave things be.
    console.log("No CSP header set, proceeding");
    return { responseHeaders: requestDetails.responseHeaders };
  } else {
    // remove the CSP header.
    requestDetails.responseHeaders[cspHeaderIdx].value = requestDetails.responseHeaders[cspHeaderIdx].value.replace("connect-src", "connect-src " + apiEndpoint);
    requestDetails.responseHeaders[cspHeaderIdx].value = requestDetails.responseHeaders[cspHeaderIdx].value.replace("script-src", "script-src " + apiEndpoint);
    requestDetails.responseHeaders[cspHeaderIdx].value = requestDetails.responseHeaders[cspHeaderIdx].value.replace("default-src", "default-src " + apiEndpoint);

    // // add our domain to the CSP header.
    // const modifiedCspHeaderValues = [];
    // const cspHeaderValues = cspHeader.value.split(";");
    // console.log("cspHeaderValues", cspHeaderValues);
    // for (const cspHeaderValue of cspHeaderValues) {
    //   if (cspHeaderValue.trim().startsWith("connect-src ")) {
    //     modifiedCspHeaderValues.push(cspHeaderValue + " " + apiDomain + " ");
    //   } else {
    //     modifiedCspHeaderValues.push(cspHeaderValue);
    //   }
    // }
    // console.log("modifiedCspHeaderValues", modifiedCspHeaderValues);

    // requestDetails.responseHeaders[cspHeaderIdx].value = modifiedCspHeaderValues.join(";");
    // console.log("csp header", requestDetails.responseHeaders[cspHeaderIdx].value);
    console.log("headers", requestDetails.responseHeaders);

    return {
      responseHeaders: requestDetails.responseHeaders
    }
  }

}

browser.webRequest.onHeadersReceived.addListener(
  modifyHeaders,
  { urls: ["https://boardgamearena.com/gamestats?player=*&game_id=1741"] },
  ["blocking", "responseHeaders"],
);